import { Component, OnInit, ɵɵqueryRefresh } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-information',
  templateUrl: './information.component.html',
  styleUrls: ['./information.component.css']
})
export class InformationComponent implements OnInit {

  products:any;
  cartproducts:any;
  constructor(private api: ApiService) { }

  ngOnInit(): void {
    this.showdata();
    this.refresh();
  }

  showdata = () => {
      this.api.getdata().subscribe((data:any)=>{
          this.products = data;          
          for(let i = 0; i < this.products.length; i++)
          {
            let exists = false;
            for(let j = 0; j < this.cartproducts.length; j++)
            {
              if(this.products[i].id == this.cartproducts[j].id)
              {
                exists = true;
                break;
              }
            }
            this.products[i]["incart"] = exists ? "Y" : "N";
          }
      });
  }

  addproduct(id:number)
  {
    let cartproducts = new Array();
    cartproducts = JSON.parse(localStorage.getItem("products") || '[]');
    let exists = false;
    for(let i = 0; i < cartproducts.length; i++)
    {
      if(cartproducts[i].id == id){
        exists = true;
        break;
      }
    }
    if(!exists)
    {
      for(let i = 0; i < this.products.length; i++)
      {
        if(this.products[i].id == id)
        {
          cartproducts.push(this.products[i]);
          this.products[i]["incart"] = "Y";
        }
      }
    }
    localStorage.setItem("products", JSON.stringify(cartproducts));
    this.refresh();
  }

  removeproduct(id:number)
  {
    let cartproducts = new Array();
    cartproducts = JSON.parse(localStorage.getItem("products") || '[]');
    let newcartproducts = new Array();
    for(let i = 0; i < cartproducts.length; i++)
    {
      if(cartproducts[i].id != id){
        newcartproducts.push(cartproducts[i]);
      }
    }
    for(let i = 0; i < this.products.length; i++)
    {
      if(this.products[i].id == id)
      {
        cartproducts.push(this.products[i]);
        this.products[i]["incart"] = "N";
      }
    }
    localStorage.setItem("products", JSON.stringify(newcartproducts));
    this.refresh();
  }

  refresh()
  {
    this.cartproducts = JSON.parse(localStorage.getItem("products") || '[]');
  }

}
